#include <stdio.h>

int main(int argc,char *argv[]){
    int telefono1 = 1234567;
    int telefono2 = 6456457;
    printf("El telefono es %i \n",telefono1);
    
    printf("\n");
    return 0;
}