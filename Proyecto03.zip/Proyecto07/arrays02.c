#include <stdio.h>

int main(int argc,char *argv[]){
    int telefono[10];
    telefono[0] = 12345;
    telefono[1] = 23456;
    telefono[2] = 34567;
   
    printf("El telefono es %i \n",telefono[30]);
    
    printf("\n");
    return 0;
}