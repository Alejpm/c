/*
    Variables
    por Alejandro Porter
*/
#include <stdio.h>

int main(int argc,char *argv[]){
    int miEdad = 42;
    printf("La edad que tienes es de %i años \n", miEdad);
    
    return 0;
}