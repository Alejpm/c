/*
    Programa agenda
    v1
    por Alejandro Porter
*/

#include <stdio.h>

int main(int argc,char *argv[]){
    // Mensaje de bienvenida
    printf("Programa agenda v1.0 \n");
    printf("Selecciona una opción: \n");
    printf("\t 1 - Listado de registros \n");
    printf("\t 2 - Introducir un registro \n");
    printf("\t 3 - eliminar un registro \n");
    printf("\t 4 - Buscar un registro \n");
    printf("\t 5 - Actualizar un registro \n");
    printf("\t Tu opción: \n");
    return 0;
}