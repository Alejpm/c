#include <stdio.h>

int main(int argc,char *argv[]){

    int i = 50;

    do{
        printf("Hola me estoy ejecutando");
        i = i + 1;
    }while(i > 10);
    
    
    printf("\n");
    return 0;
}