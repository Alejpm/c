#include <stdio.h>

int main(int argc,char *argv[]){
    for(int dia = 25;dia<=5;dia = dia - 5){
        printf("Hoy es el dia número %i del mes \n",dia);
    
    }
    printf("\n");
    return 0;
}