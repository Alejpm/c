#include <stdio.h>

int main(int argc,char *argv[]){

    int i = 50;

    while(i > 10){
        printf("El programa esta funcionando \n");
        i = i + 1;
    
    }
    
    printf("\n");
    return 0;
}