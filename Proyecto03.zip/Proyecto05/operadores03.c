#include <stdio.h>

int main(int argc,char *argv[]){
    float numero1 = 4;
    float numero2 = 3;
    
    float resultado = numero1 / numero2;
    printf("El resultado de la operación es: %i \n",resultado);
    
    return 0;



}