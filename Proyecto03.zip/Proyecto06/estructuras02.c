#include <stdio.h>

int main(int argc,char *argv[])[
    int edad = 42;
    if(edad < 40)[
        // Esto se ejecuta en el caso verdadero
        printf("Eres una persona muy joven");    
        if(edad < 10)[
            printf("Eres un niño \n");
        
        ]else[
            // Esto se ejecuta en el caso falso
            printf(" \n");
    ]else{
     if(edad < 40)[
        // Esto se ejecuta en el caso verdadero
        printf("Eres una persona muy joven");    
        if(edad < 30)[
            printf("Eres un niño \n");
        
        ]else[
            // Esto se ejecuta en el caso falso
            printf("Ya no eres tan joven \n");
    
     ]
     return 0;
]